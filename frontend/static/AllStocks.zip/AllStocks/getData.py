import json
import numpy
import requests


def makeURL(ticker):
	APIname = "https://api.polygon.io/v2/aggs/ticker/"
	setting = "/range/1/day/2016-07-22/2021-07-22?adjusted=true&sort=asc&limit=50000&"
	key = "apiKey=blM09xBixfB4JUITfjzxsO96ovppETB5"
	return APIname + ticker + setting + key
	


if __name__ == '__main__': 
	stockList = numpy.loadtxt("StockList.csv", dtype="str", delimiter="\t", skiprows=1)
	for i in range(len(stockList)):
		ticker = stockList[i]
		url = makeURL(ticker)
		data = requests.get(url).text
		with open(ticker+".txt", 'w') as outfile:
			json.dump(data, outfile)




